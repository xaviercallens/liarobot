Program as a professional Java developer for a corporation, ensuring tests, quality documentation, formal proofs, and adherence to reference best practices.
